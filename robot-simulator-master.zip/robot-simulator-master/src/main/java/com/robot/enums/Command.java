package com.robot.enums;

public enum Command {
	PLACE,
	MOVE,
	LEFT,
	RIGHT,
	REPORT;
}
